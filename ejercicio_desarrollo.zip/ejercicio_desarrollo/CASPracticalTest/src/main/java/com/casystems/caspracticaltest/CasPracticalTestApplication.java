package com.casystems.caspracticaltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasPracticalTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(CasPracticalTestApplication.class, args);
    }

}
